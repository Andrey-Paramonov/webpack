export function loadHome(container) {
    const headline = document.createElement('h1');
    headline.textContent = 'Добро пожаловать в Crumble Cafe!';
    const description = document.createElement('p');
    description.textContent = 'Лучшая выпечка в городе, приготовленная с любовью.';
    
    container.appendChild(headline);
    container.appendChild(description);
}
