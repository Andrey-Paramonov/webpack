import './style.css';
import { loadHome } from './home';
import { loadMenu } from './menu';
import { loadContact } from './contact';

function createNav(activeTabName) {
    const content = document.getElementById('content');
    const nav = document.createElement('nav');

    const tabs = [
        { name: 'Главная', action: loadHome, id: 'home' },
        { name: 'Меню', action: loadMenu, id: 'menu' },
        { name: 'Контакты', action: loadContact, id: 'contact' }
    ];

    tabs.forEach(tab => {
        const btn = document.createElement('button');
        btn.textContent = tab.name;
        
        if (tab.id === activeTabName) {
            btn.classList.add('active');
        }

        btn.onclick = () => {
            clearAndLoad(tab.action, tab.id);
        };
        nav.appendChild(btn);
    });

    content.appendChild(nav);
}

export function clearAndLoad(loadFunction, tabId) {
    const content = document.getElementById('content');
    content.innerHTML = ''; 
    createNav(tabId); 
    
    const tabContentDiv = document.createElement('div');
    tabContentDiv.classList.add('tab-content');
    content.appendChild(tabContentDiv);
    
    loadFunction(tabContentDiv);
}

document.addEventListener('DOMContentLoaded', () => {
    clearAndLoad(loadHome, 'home');
});
