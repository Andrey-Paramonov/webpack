export function loadContact(container) {
    const headline = document.createElement('h1');
    headline.textContent = 'Контакты';
    container.appendChild(headline);

    const info = document.createElement('p');
    info.innerHTML = `
        <strong>Адрес:</strong> ул. Выпечки, д. 12<br>
        <strong>Телефон:</strong> +7 (999) 123-45-67<br>
        <strong>Часы работы:</strong> 8:00 - 21:00<br>
        <strong>Мы в соцсетях:</strong> <a href="#">@crumble_cafe</a>
    `;
    container.appendChild(info);

    const bookBtn = document.createElement('button');
    bookBtn.textContent = 'Забронировать столик';
    bookBtn.style.margin = '10px 0';
    bookBtn.onclick = () => {
        alert('Столик забронирован! Мы вам перезвоним.');
    };
    container.appendChild(bookBtn);

    const formHeadline = document.createElement('h3');
    formHeadline.textContent = 'Обратная связь';
    container.appendChild(formHeadline);

    const form = document.createElement('form');

    const nameInput = document.createElement('input');
    nameInput.placeholder = 'Ваше имя (мин. 2 символа)';
    
    const emailInput = document.createElement('input');
    emailInput.placeholder = 'Ваш Email';

    const messageInput = document.createElement('textarea');
    messageInput.placeholder = 'Сообщение...';

    const submitBtn = document.createElement('button');
    submitBtn.type = 'submit';
    submitBtn.textContent = 'Отправить';

    form.appendChild(nameInput);
    form.appendChild(emailInput);
    form.appendChild(messageInput);
    form.appendChild(submitBtn);
    container.appendChild(form);

    form.onsubmit = (e) => {
        e.preventDefault();
        nameInput.classList.remove('error-input');
        emailInput.classList.remove('error-input');

        let isValid = true;
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (nameInput.value.trim().length < 2) {
            nameInput.classList.add('error-input');
            isValid = false;
        }

        if (!emailRegex.test(emailInput.value.trim())) {
            emailInput.classList.add('error-input');
            isValid = false;
        }

        if (isValid) {
            alert(`Спасибо, ${nameInput.value.trim()}!`);
            form.reset();
        }
    };
}
