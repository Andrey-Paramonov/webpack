import menuData from './menu-data.json';

// Импортируем только проверенную картинку круассана
import croissantImg from './images/i.webp'; 

export function loadMenu(container) {
    let visits = localStorage.getItem('menuVisits') || 0;
    visits = parseInt(visits) + 1;
    localStorage.setItem('menuVisits', visits);

    const headline = document.createElement('h1');
    headline.textContent = 'Наше Меню';
    container.appendChild(headline);

    const counterText = document.createElement('p');
    counterText.textContent = `Вы открывали это меню раз: ${visits}`;
    counterText.style.fontStyle = 'italic';
    counterText.style.color = '#666';
    container.appendChild(counterText);

    menuData.forEach(item => {
        const card = document.createElement('div');
        card.classList.add('menu-card');

        const name = document.createElement('h3');
        name.textContent = `${item.name} — ${item.price} руб.`;
        
        const desc = document.createElement('p');
        desc.textContent = item.description;

        card.appendChild(name);
        card.appendChild(desc);

        const img = document.createElement('img');
        img.alt = item.name;

        if (item.name === 'Круассан') {
            img.src = croissantImg;
            card.appendChild(img);
        } else if (item.name === 'Тирамису') {
            // Чтобы Webpack не ругался на буквы расширения, ставим красивое Тирамису из интернета
            img.src = 'https://unsplash.com';
            card.appendChild(img);
        } else if (item.name === 'Чизкейк') {
            // Чизкейк из интернета
            img.src = 'https://unsplash.com';
            card.appendChild(img);
        }

        container.appendChild(card);
    });
}
